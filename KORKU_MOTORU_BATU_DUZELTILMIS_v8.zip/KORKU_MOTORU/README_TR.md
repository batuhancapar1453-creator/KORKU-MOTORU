# KORKU MOTORU – 20 bölümlük otomatik yayın paketi

- 20 yeni hikâye, 10 gün, günde 2 yayın. Mevcut başarılı video_001 pilotu bu 20 yeni hikâyeye dahil değildir.
- Zamanlama: 09:00 ve 12:00 Türkiye saati (GitHub cron: 06:00 ve 09:00 UTC).
- Her video 180 saniye, 45 sahne, 9:16 ve 1080×1920.
- Batu karakterinin yüz, saç, göz ve kıyafet tanımı tüm hikâyelerde sabittir; mekân/ışık/atmosfer hikâyeye göre değişir.
- Görselde rastgele yazı üretilmez; konuşma kutusu ve telefon mesajları Türkçe metin olarak sonradan çizilir.
- Edge TTS: tr-TR-AhmetNeural, daha anlaşılır tempo için -7% hız ve -3Hz perde.
- Cloudflare 3030 hatalarında 3 farklı güvenli prompt denemesi; başarılı sahneler cache ile korunur.
- YouTube herkese açık yükleme; yayın geçmişi git ile saklanır ve çift yükleme engellenir.

## GitHub Secrets
CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_API_TOKEN, YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN.

## Kurulum
1. ZIP içeriğini depoya çıkarın.
2. ZIP dosyasını depo köküne `KORKU_MOTORU_BATU_DUZELTILMIS_v4.zip` adıyla koyun.
3. `.github/workflows/korku_motoru.yml` dosyasını workflow olarak ekleyin.
4. Secrets değerlerini kontrol edin.
5. Actions'tan manuel çalıştırma sıradaki yayınlanmamış bölümü üretir ve yükler.

Not: Character lock metinsel yönlendirmeyle tutarlılığı artırır; görsel üretim modelinde her karede piksel düzeyinde aynı yüzü garanti etmez. Ayrıca Cloudflare ve GitHub ücretsiz kota/süre sınırları sağlayıcı koşullarına bağlıdır.


## v5 güvenlik filtresi dayanıklılığı
- Cloudflare 3030 için dört aşamalı prompt denemesi bulunur.
- Dört denemede de güvenlik filtresi tek sahneyi reddederse, aynı bölümdeki en yakın başarılı görselden hafifçe yeniden kadrajlanmış bir yedek kare oluşturulur.
- Diğer API/ağ hataları gizlenmez; normal hata olarak raporlanır.

## v6 - Cloudflare ücretsiz kota koruması
- Cloudflare `4006` / günlük 10.000 neuron kotası dolduğunda yeniden deneme yapılmaz ve yeni Cloudflare istekleri durdurulur.
- Eksik sahneler için Wikimedia Commons'ta konuyla ilişkili görsel aranır; kaynak/lisans bilgisi bölüm klasöründeki `commons_attributions.txt` dosyasına yazılır.
- Commons'ta uygun görsel bulunamazsa mevcut bölüm görsellerinden kontrollü yedek varyasyon kullanılır. Bu yedek yeni bir AI üretimi değildir ve Batu'nun her sahnede aynı şekilde görünmesini garanti etmez.
- Mevcut görsel önbelleği korunur. `IMAGE_WORKERS=1` ile kota hatasından sonra gereksiz eşzamanlı istekler azaltılır.
- Ücretsiz Cloudflare kotası, günde iki adet 45 sahneli bölümün tüm sahnelerini AI ile üretmeye yetmeyebilir. Yedek kaynak, ücretsiz otomatik üretimin kesintiye uğramamasına yardımcı olur; görsel tutarlılık açısından AI üretiminin birebir karşılığı değildir.


## v7 - Wikimedia yedek aramasının iyileştirilmesi

Cloudflare günlük ücretsiz neuron kotası dolduğunda yeni Cloudflare isteği gönderilmez. Eksik sahneler için Wikimedia Commons araması, karakter tanımını arama terimlerinden çıkarıp sahnenin mekân/nesne kelimelerine odaklanır; sahneye özel arama sonuç vermezse mekân türüne göre alternatif sorgular dener. Bulunan görsellerin kaynak/lisans bilgileri `commons_attributions.txt` dosyasına yazılır. Aynı bölümde en az bir geçerli görsel elde edildikten sonra Commons'ta bulunamayan sahneler için kontrollü yakın-sahne önbellek yedeği kullanılabilir. Commons erişimi veya uygun sonuçlar garanti değildir; bu durumda üretim açık hata verir, sessizce boş/bozuk görsel üretmez. Commons fotoğrafları Batu'nun karakter tutarlılığını garanti etmez.


## V8: Cloudflare kotası dolunca AI yedek motoru

Cloudflare Workers AI ana görsel sağlayıcısı olarak kalır. Günlük ücretsiz neuron kotası (4006) dolduğunda eksik sahneler, aynı sahneye ait tam AI promptu ile AI Horde'un gönüllü GPU ağına gönderilir. Rastgele Wikimedia/stock fotoğrafları kullanılmaz. AI Horde ücretsiz ve topluluk desteklidir; anonim istekler en düşük öncelikte olduğundan bekleme süresi değişebilir ve kesintisiz/sınırsız hizmet garantisi yoktur. İsteğe bağlı olarak GitHub Secrets içine `AI_HORDE_API_KEY` eklenirse anonim kullanım yerine kişisel ücretsiz hesap anahtarı kullanılır; anahtar eklenmezse anonim anahtar ile çalışır.
