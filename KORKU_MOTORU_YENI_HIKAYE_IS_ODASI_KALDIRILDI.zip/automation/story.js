import * as THREE from 'three';
import { Toon, flap, blinkAt } from '/engine/src/toon.js';
export const NAME='son-gorulme'; export const FPS=30; export let DUR=40; export const CUES=[];
export const LOOK={hero:{headW:276,headH:258,body:'coat',cloth:'#28364b',clothDark:'#17202e',height:1.78,hair:'#211d26'}};
let actor, phone, screen, lamp, room, words;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export async function setup(ctx){
 words=ctx.words; DUR=Math.ceil((words.at(-1).end+.8)*FPS)/FPS; const s=ctx.scene; s.background=new THREE.Color('#090d18');
 const mat=(c,r=.85)=>new THREE.MeshStandardMaterial({color:c,roughness:r});
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(14,14),mat('#242631')); floor.rotation.x=-Math.PI/2; floor.position.y=-.03; s.add(floor);
 const back=new THREE.Mesh(new THREE.PlaneGeometry(10,5),mat('#252634')); back.position.set(0,2.4,-3); s.add(back);
 const side=new THREE.Mesh(new THREE.PlaneGeometry(6,5),mat('#171d2b')); side.rotation.y=Math.PI/2; side.position.set(-5,2.4,0); s.add(side);
 const door=new THREE.Group(); const slab=new THREE.Mesh(new THREE.BoxGeometry(1.45,2.8,.14),mat('#49372f')); slab.position.set(3.1,1.4,-2.88); door.add(slab); const knob=new THREE.Mesh(new THREE.SphereGeometry(.07,16,12),mat('#b58c4c')); knob.position.set(2.55,1.35,-2.75); door.add(knob); s.add(door);
 const bed=new THREE.Mesh(new THREE.BoxGeometry(2.8,.45,1.5),mat('#353b50')); bed.position.set(-2,.3,-1.2); s.add(bed);
 const lampMesh=new THREE.Mesh(new THREE.SphereGeometry(.13,20,16),new THREE.MeshBasicMaterial({color:'#ffbd75'})); lampMesh.position.set(-3.7,2.5,-1); s.add(lampMesh);
 lamp=new THREE.PointLight('#ffb36b',24,8,2); lamp.position.copy(lampMesh.position); s.add(lamp);
 const phoneBody=new THREE.Mesh(new THREE.BoxGeometry(.38,.72,.055),mat('#080a10',.3)); phoneBody.position.set(.55,.78,.9); phoneBody.rotation.x=-.18; s.add(phoneBody); phone=phoneBody;
 screen=new THREE.Mesh(new THREE.PlaneGeometry(.32,.61),new THREE.MeshBasicMaterial({color:'#9bc9e8'})); screen.position.set(.55,.78,.932); screen.rotation.x=-.18; s.add(screen);
 const fill=new THREE.AmbientLight('#8290b8',.42); s.add(fill);
 actor=new Toon(LOOK.hero,s); actor.show();
 const key=new THREE.DirectionalLight('#b9c9ff',1.2); key.position.set(-3,5,4); s.add(key);
 CUES.push({t:0,type:'whoosh'},{t:DUR*.34,type:'whoosh'},{t:DUR*.68,type:'whoosh'},{t:DUR*.43,type:'cut'},{t:DUR*.83,type:'boom'},{t:0,type:'wind',dur:DUR});
}
export function frame(t,ctx){
 const {cam,env}=ctx; const p=clamp(t/DUR,0,1); const close=p>.72;
 const targetX=p<.28?-.2:p<.58?1.0:.15; const camZ=p<.25?7.6:p<.6?6.2:4.9;
 cam.position.set(targetX,1.9+(p>.65?.15:0),camZ); cam.lookAt(p<.4?0:close?.55:0,1.35,-.7); cam.fov=p>.75?37:48; cam.updateProjectionMatrix();
 actor.place(-.95,0,.15,cam,[1,1,1],p>.72?1.06:1); actor.draw({mouth:flap(env,t),expr:p<.25?'worried':p<.55?'focused':'terrified',look:close?.8:-.25,lookY:close?-.25:0,blink:blinkAt(t,4),brow:p>.65?.9:.3,lean:p>.82?3:0,bob:Math.sin(t*2)*.012});
 phone.position.y=.78+Math.sin(t*8)*.025*(p>.18&&p<.42?1:0); screen.material.color.set(p>.18&&p<.42?'#b8f0ff':p>.68?'#d9e8ff':'#7896b5');
 lamp.intensity=19+5*Math.sin(t*11)+(p>.82?8*Math.sin(t*27):0);
 door.rotation.y=p>.48?-.06*Math.sin((t-DUR*.48)*7):0;
 return {blur:p>.45&&p<.5?3:0};
}
export function overlay(g,t,ctx){
 const p=t/DUR; let msg='';
 if(p>.18&&p<.30) msg='SAKIN KAPIYI AÇMA'; else if(p>.43&&p<.55) msg='IŞIĞI KAPAT'; else if(p>.72&&p<.86) msg='BEN HENÜZ EVE GELMEDİM';
 if(!msg)return; g.save(); g.globalAlpha=.94; g.fillStyle='rgba(7,12,22,.9)'; const w=Math.min(760,g.canvas.width*.82),h=90,x=(g.canvas.width-w)/2,y=g.canvas.height*.16; g.beginPath(); g.roundRect(x,y,w,h,20); g.fill(); g.fillStyle='#d9efff'; g.font='bold 34px Arial'; g.textAlign='center'; g.textBaseline='middle'; g.fillText(msg,g.canvas.width/2,y+h/2,w-34); g.restore();
}
