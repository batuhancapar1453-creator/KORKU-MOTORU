import json, pathlib, subprocess, re, sys
from datetime import timedelta
root=pathlib.Path(__file__).resolve().parents[1]
idx=int(sys.argv[1]); eps=json.load(open(root/'automation/episodes.json',encoding='utf-8')); ep=eps[idx-1]
sd=root/'stories'/'son-gorulme'; (sd/'voice').mkdir(parents=True,exist_ok=True); (sd/'audio').mkdir(exist_ok=True)
(sd/'story.js').write_text((root/'automation'/'story.js').read_text(encoding='utf-8'),encoding='utf-8')
(sd/'SCRIPT.md').write_text('# '+ep['title']+'\n\n'+ep['text'],encoding='utf-8')
sub=sd/'voice'/'captions.srt'; mp3=sd/'voice'/'voice.mp3'; wav=sd/'voice'/'voice.wav'
subprocess.run(['edge-tts','--voice','tr-TR-AhmetNeural','--rate','-8%','--pitch','-8Hz','--text',ep['text'],'--write-media',str(mp3),'--write-subtitles',str(sub)],check=True)
subprocess.run(['ffmpeg','-y','-v','error','-i',str(mp3),'-ar','24000','-ac','1',str(wav)],check=True)
def sec(s):
 h,m,x=s.replace(',','.').split(':'); return int(h)*3600+int(m)*60+float(x)
raw=sub.read_text(encoding='utf-8-sig'); blocks=re.split(r'\n\s*\n',raw.strip()); words=[]
for b in blocks:
 lines=b.splitlines();
 if len(lines)<3 or '-->' not in lines[1]: continue
 a,z=lines[1].split('-->'); start,end=sec(a.strip()),sec(z.strip()); txt=' '.join(lines[2:]); ws=re.findall(r"[\wÇĞİÖŞÜçğıöşü'-]+[.,!?…:]?",txt,flags=re.UNICODE)
 if not ws: continue
 weights=[max(1,len(re.sub(r'\W','',w))) for w in ws]; total=sum(weights); cur=start
 for w,weight in zip(ws,weights):
  dur=(end-start)*weight/total; words.append({'word':w,'start':round(cur,3),'end':round(cur+dur,3)}); cur+=dur
json.dump({'words':words},open(sd/'voice'/'words.json','w',encoding='utf-8'),ensure_ascii=False)
subprocess.run([sys.executable,str(root/'tools'/'zarf.py'),str(wav),str(sd/'voice'/'env.json'),'30'],check=True)
print('Episode',idx,'voice seconds',round(sec('00:00:00,000')+words[-1]['end'],1),'words',len(words))
