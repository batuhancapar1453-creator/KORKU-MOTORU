import * as THREE from 'three';
import { stoneTex, woodTex, carpetTex, wallTex, sootTex, ciniTex, frizTex, painted, flat } from '/engine/src/paint.js';
import { Toon, flap, blinkAt } from '/engine/src/toon.js';
import { glow, beam, Smoke } from '/engine/src/fx.js';
import { nightCityTex } from '/engine/src/vista.js';

export const NAME='son-gorulme'; export const FPS=30; export let DUR=40; export const CUES=[];
export const LOOK={hero:{headW:276,headH:258,body:'coat',cloth:'#28364b',clothDark:'#17202e',height:1.78,hair:'#211d26'}};
let actor, phone, screen, lamp, door, doorLight, windowLight, episode=1, envGroup, smoke;
const clamp=(x,a,b)=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x,0,1);return x*x*(3-2*x)};
const mat=(c,r=.82,extra={})=>new THREE.MeshStandardMaterial({color:c,roughness:r,...extra});
const box=(g,w,h,d,m,x,y,z)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);g.add(o);return o;};
const plane=(g,w,h,m,x,y,z,ry=0)=>{const o=new THREE.Mesh(new THREE.PlaneGeometry(w,h),m);o.position.set(x,y,z);o.rotation.y=ry;g.add(o);return o;};
function shadowize(g){g.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}})}
function makeDoor(g,x=2.85,z=-3.8){
 const frame=mat('#5b392b'), wood=painted(woodTex({base:'#563323',rep:[1,2],vertical:true}));
 box(g,1.72,3.12,.28,frame,x,1.56,z-.04); door=new THREE.Group(); door.position.set(x,0,z+.12);g.add(door);
 box(door,1.42,2.86,.12,wood,0,1.43,0);
 for(let y of [.32,1.48,2.55]) box(door,1.17,.055,.035,mat('#8c6040'),0,y,.08);
 for(let xx of [-.47,.47]) box(door,.055,2.05,.035,mat('#70472f'),xx,1.45,.08);
 const knob=new THREE.Mesh(new THREE.SphereGeometry(.075,20,14),mat('#c9a15c',.24,{metalness:.72}));knob.position.set(-.48,1.32,.13);door.add(knob);
 const trim=mat('#b18a59'); for(let xx of [-.86,.86])box(g,.12,3.28,.22,trim,x+xx,1.64,z-.01);box(g,1.82,.13,.22,trim,x,3.25,z-.01);
 doorLight=new THREE.PointLight('#d7e6ff',2.2,5,2);doorLight.position.set(x,2.3,z-1.1);g.add(doorLight);
}
function makeWindow(g,x=-3.3,z=-3.82){
 const frame=mat('#50382e'), glass=new THREE.MeshBasicMaterial({map:nightCityTex({w:1024,h:512,seed:episode*19}),side:THREE.DoubleSide});
 box(g,2.25,2.05,.2,frame,x,2.18,z-.05);plane(g,1.98,1.78,glass,x,2.2,z+.07);
 for(let xx of [-.52,.52])box(g,.055,1.82,.06,mat('#8a684d'),x+xx,2.2,z+.13);box(g,2,.06,.06,mat('#8a684d'),x,2.2,z+.13);
 const curtain=painted(carpetTex({base:'#302b42',band:'#6e4d62',rows:8,rep:[1,2]}));
 for(let xx of [-1.22,1.22]){const c=box(g,.35,2.35,.13,curtain,x+xx,2.15,z+.24);c.rotation.z=xx<0?-.04:.04;}
 windowLight=new THREE.SpotLight('#8daee8',34,18,Math.PI/5,.72,1.3);windowLight.position.set(x,3.5,1.5);windowLight.target.position.set(x,1.2,-3.5);windowLight.castShadow=true;windowLight.shadow.mapSize.set(1024,1024);g.add(windowLight,windowLight.target);
}
function buildBedroom(g){
 const floor=painted(woodTex({base:'#392c2b',rep:[3,4]}));const walls=painted(wallTex({base:'#45404b',frame:'#766052',night:true,cols:5,rows:[0,1],rep:[2,1]}));
 const carpet=painted(carpetTex({base:'#29263a',band:'#78604d',rows:6,rep:[2,2]}));
 box(g,12,.18,12,floor,0,-.1,0);plane(g,12,5.8,walls,0,2.8,-4);plane(g,12,5.8,walls,0,2.8,4,Math.PI);plane(g,8,5.8,walls,-6,2.8,0,Math.PI/2);plane(g,8,5.8,walls,6,2.8,0,-Math.PI/2);
 box(g,12,.32,.16,mat('#6c4a39'),0,.18,-3.9);box(g,12,.32,.16,mat('#6c4a39'),0,.18,3.9);
 plane(g,5.8,4.5,carpet,-1.1,.005,1,0);makeWindow(g,-3.2,-3.82);makeDoor(g,3.1,-3.82);
 // bed, rumpled quilt, pillows and carved headboard
 box(g,3.25,.38,2.15,mat('#302a35'),-1.7,.36,-1.35);box(g,3.15,.22,2.02,painted(carpetTex({base:'#35445a',band:'#64748b',rows:9,rep:[2,2]})),-1.7,.65,-1.35);
 box(g,3.3,1.22,.16,mat('#553b32'),-1.7,.94,-2.43);for(let x of [-2.55,-.85])box(g,.12,1.4,.14,mat('#8b6749'),x,.88,-2.43);
 for(let x of [-2.45,-.95]){box(g,.95,.18,.62,mat('#b6b0b0'),x,.84,-1.95);}
 // bedside table, drawer fronts, lamp
 box(g,.78,.85,.72,mat('#513a30'),.55,.44,-1.9);for(let y of [.25,.58])box(g,.68,.23,.035,mat('#76533d'),.55,y,-1.52);
 const bulb=new THREE.Mesh(new THREE.SphereGeometry(.16,24,16),new THREE.MeshBasicMaterial({color:'#ffd39a'}));bulb.position.set(.55,1.35,-1.85);g.add(bulb);
 lamp=new THREE.PointLight('#ffb978',28,9,2);lamp.position.copy(bulb.position);g.add(lamp);glow(g,bulb.position,'#ffb978',.55,.7);
 // wardrobe and framed pictures
 box(g,1.6,2.7,.72,mat('#3a2c2a'),-4.45,1.35,-2.95);for(let x of [-4.95,-4.15])box(g,.04,2.55,.06,mat('#806044'),x,1.35,-2.56);
 box(g,.82,1.05,.09,mat('#a98b68'),1.15,2.5,-3.82);box(g,.68,.88,.025,mat('#1d2531'),1.15,2.5,-3.75);
}
function buildHall(g,stairs=false){
 const floor=painted(woodTex({base:'#30252a',rep:[2,5]})), wall=painted(sootTex({base:'#34303c',rep:[2,2]}));
 box(g,7,.2,15,floor,0,-.1,0);plane(g,7,5.8,wall,0,2.8,-7.4);plane(g,7,5.8,wall,0,2.8,7.4,Math.PI);plane(g,15,5.8,wall,-3.5,2.8,0,Math.PI/2);plane(g,15,5.8,wall,3.5,2.8,0,-Math.PI/2);
 for(let y of [.22,.34]){box(g,7,.08,.1,mat('#805b46'),0,y,-7.25);box(g,7,.08,.1,mat('#805b46'),0,y,7.25);}
 makeDoor(g,0,-7.22); // deep vanishing-point door
 for(let i=0;i<5;i++){let x=-2.8+i*1.4;box(g,.035,5.3,.07,mat('#6a5147'),x,2.7,-7.28);}
 for(let z of [-5,-2,1,4]){const s=new THREE.PointLight('#d9b17a',3.2,5,2);s.position.set(-2.75,3.2,z);g.add(s);const b=new THREE.Mesh(new THREE.SphereGeometry(.09,16,12),new THREE.MeshBasicMaterial({color:'#ffd39a'}));b.position.copy(s.position);g.add(b);glow(g,b.position,'#ffc77f',.38,.5);}
 if(stairs){for(let i=0;i<10;i++){let z=3.8-i*.72,y=.18+i*.24;box(g,2.3,.22,.82,painted(stoneTex({base:'#5b5153'})),1.5,y,z);}
 const rail=mat('#8b674b');for(let i=0;i<9;i++){let z=3.5-i*.72,y=.5+i*.24;box(g,.08,1,.08,rail,.42,y,z);}box(g,.1,.1,7,rail,.42,1.55,0);}
}
function buildLiving(g){
 buildBedroom(g); // retain room shell then overlay living-room furniture
 box(g,3.1,.62,1.05,mat('#35404b'),-1.1,.48,-.25);box(g,3.05,.14,1.0,mat('#6b5960'),-1.1,.86,-.25);
 box(g,1.45,.48,.8,mat('#4c372f'),1.2,.25,-.4);box(g,1.4,.06,.75,mat('#916c4b'),1.2,.52,-.4);
 // large mirror with ornate frame
 box(g,1.62,2.75,.18,mat('#96764c'),2.55,1.75,-3.68);const mirror=new THREE.Mesh(new THREE.PlaneGeometry(1.37,2.5),new THREE.MeshPhysicalMaterial({color:'#a5b1bd',metalness:.88,roughness:.12,reflectivity:1}));mirror.position.set(2.55,1.78,-3.56);g.add(mirror);
 for(let y of [.48,3.05])box(g,1.8,.11,.2,mat('#c2a16a'),2.55,y,-3.55);
}
function buildCloset(g){buildBedroom(g);box(g,2.1,2.8,.22,mat('#241f25'),-4.5,1.4,-2.4);for(let x of [-5.45,-3.55])box(g,.1,2.95,.25,mat('#76533d'),x,1.48,-2.24);for(let i=0;i<5;i++){let c=box(g,.62,.055,.07,mat('#5a514b'),-4.5,2.45-i*.42,-2.15);c.rotation.z=.02;}}
function buildScene(g){
 if(episode===2||episode===9)buildHall(g,false);
 else if(episode===8)buildHall(g,true);
 else if(episode===4||episode===10)buildLiving(g);
 else if(episode===6)buildCloset(g);
 else buildBedroom(g);
 // Story-specific hero props: the set itself tells the viewer which chapter they are in.
 if(episode===3){ // photograph from the future, framed on the wall
   box(g,1.18,1.52,.13,mat('#9b774d'),1.45,2.05,-3.68);
   box(g,1.02,1.34,.035,mat('#a9b4c1',.45),1.45,2.05,-3.58);
   const shadowFigure=new THREE.Mesh(new THREE.SphereGeometry(.22,20,16),mat('#171b27'));
   shadowFigure.position.set(1.48,1.75,-3.53);g.add(shadowFigure);
 }
 if(episode===5){ // clock stopped at 03:17
   box(g,.9,.48,.12,mat('#171b22'),-3.9,2.65,-3.66);
   const digits=new THREE.Mesh(new THREE.PlaneGeometry(.72,.28),new THREE.MeshBasicMaterial({color:'#ff564e'}));digits.position.set(-3.9,2.65,-3.58);g.add(digits);
   const canvas=document.createElement('canvas');canvas.width=512;canvas.height=180;const c=canvas.getContext('2d');c.fillStyle='#090b10';c.fillRect(0,0,512,180);c.fillStyle='#ff625b';c.font='bold 112px monospace';c.textAlign='center';c.fillText('03:17',256,130);const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;digits.material.map=tex;digits.material.color.set('#ffffff');digits.material.needsUpdate=true;
 }
 if(episode===7){ // old landline and a photograph of the mother
   box(g,1.35,.82,.8,mat('#49372d'),1.35,.42,-1.75);
   const base=box(g,.72,.16,.46,mat('#24232a'),1.35,.92,-1.72);base.rotation.x=-.08;
   const handset=new THREE.Mesh(new THREE.CapsuleGeometry(.085,.62,5,12),mat('#171a20'));handset.rotation.z=Math.PI/2;handset.position.set(1.35,1.1,-1.72);g.add(handset);
   box(g,.78,1.05,.08,mat('#9a7957'),-3.8,2.25,-3.68);box(g,.65,.9,.025,mat('#b4a18b'),-3.8,2.25,-3.61);
 }
 if(episode===9){ // tall mirror at the end of the corridor
   box(g,1.4,3.25,.2,mat('#9c8059'),0,1.75,-6.92);
   const m=new THREE.Mesh(new THREE.PlaneGeometry(1.18,3.02),new THREE.MeshPhysicalMaterial({color:'#9da9ba',metalness:.9,roughness:.1}));m.position.set(0,1.75,-6.79);g.add(m);
 }
}
function addPhone(g){
 const body=mat('#090d16',.22,{metalness:.4});const p=box(g,.42,.78,.065,body,.65,.8,.35);p.rotation.x=-.22;phone=p;
 screen=new THREE.Mesh(new THREE.PlaneGeometry(.35,.67),new THREE.MeshBasicMaterial({color:'#8ec8ff'}));screen.position.set(.65,.8,.389);screen.rotation.x=-.22;g.add(screen);
 const glowL=new THREE.PointLight('#7ebfff',5,2,2);glowL.position.set(.65,1.05,.48);g.add(glowL);
}
export async function setup(ctx){
 const s=ctx.scene;const words=ctx.words;DUR=Math.ceil((words.at(-1).end+.8)*FPS)/FPS;
 try{const data=await (await fetch('/stories/son-gorulme/episode.json')).json();episode=Number(data.episode)||1;}catch{}
 s.background=new THREE.Color('#111421');s.fog=new THREE.FogExp2('#111421',.026);
 envGroup=new THREE.Group();s.add(envGroup);buildScene(envGroup);addPhone(envGroup);
 const ambient=new THREE.HemisphereLight('#8290b9','#211b22',.62);s.add(ambient);
 const moon=new THREE.DirectionalLight('#a7c5ff',1.45);moon.position.set(-5,8,5);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);moon.shadow.camera.left=-9;moon.shadow.camera.right=9;moon.shadow.camera.top=9;moon.shadow.camera.bottom=-9;s.add(moon);
 const rim=new THREE.SpotLight('#9bbcff',24,18,Math.PI/4,.8,1.5);rim.position.set(4,5,4);rim.target.position.set(0,1,-2);rim.castShadow=true;s.add(rim,rim.target);
 actor=new Toon(LOOK.hero,s);actor.show();
 // A faint drifting haze layer and visible volumetric shaft make the practical lights read in the room.
 try{smoke=new Smoke(s,{color:'#8793b4',opacity:.045});}catch{}
 beam(s,[-3.2,3.8,-3.5],[-1.3,.2,1.2],{r0:.12,r1:1.05,color:'#a8c5ff',strength:.15});
 CUES.push({t:0,type:'wind',dur:DUR},{t:DUR*.24,type:'whoosh'},{t:DUR*.48,type:'cut'},{t:DUR*.73,type:'boom'});
}
export function frame(t,ctx){
 const p=clamp(t/DUR,0,1),hall=episode===2||episode===8||episode===9;
 const targetX=hall?0:(p<.34?-.55:p<.68?.5:.1);const camZ=hall?9:(p<.3?8.7:p<.7?7.2:5.4);
 ctx.cam.position.set(targetX,2.0+(p>.68?.12:0),camZ);ctx.cam.lookAt(hall?0:(p<.4?-.3:.35),1.45,-2.15);ctx.cam.fov=p>.72?39:47;ctx.cam.updateProjectionMatrix();
 actor.place(hall?-.95:-1.35,0,.35,ctx.cam,[1,1,1],p>.72?1.07:1);
 actor.draw({mouth:flap(ctx.env,t),expr:p<.22?'worried':p<.55?'focused':'terrified',look:p>.72?.82:-.25,lookY:p>.72?-.2:0,blink:blinkAt(t,episode+3),brow:p>.62?.95:.3,lean:p>.82?3:0,bob:Math.sin(t*2.1)*.012});
 if(phone){phone.position.y=.8+Math.sin(t*7)*.018*(p>.18&&p<.42?1:0);screen.material.color.set(p>.18&&p<.42?'#d9f2ff':p>.7?'#e3eaff':'#7896b5');}
 if(lamp)lamp.intensity=episode===2||episode===8?0:26+5*Math.sin(t*8)+(p>.82?9*Math.sin(t*25):0);
 if(door){door.rotation.y=p>.5?-.08*Math.sin((t-DUR*.5)*6):0;}
 if(doorLight)doorLight.intensity=2+((p>.72)?9:0);
 if(windowLight)windowLight.intensity=episode===3||episode===8?42:26;
 return {blur:p>.46&&p<.51?2:0};
}
export function overlay(g,t){
 const p=t/DUR;let msg='';
 if(p>.17&&p<.29)msg='SAKIN KAPIYI AÇMA';else if(p>.43&&p<.55)msg='IŞIĞI KAPAT';else if(p>.72&&p<.86)msg='BEN HENÜZ EVE GELMEDİM';
 if(!msg)return;g.save();g.globalAlpha=.94;g.fillStyle='rgba(7,12,22,.88)';const w=Math.min(760,g.canvas.width*.82),h=90,x=(g.canvas.width-w)/2,y=g.canvas.height*.16;g.beginPath();g.roundRect(x,y,w,h,20);g.fill();g.fillStyle='#e1efff';g.font='bold 34px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(msg,g.canvas.width/2,y+h/2,w-34);g.restore();
}
