from __future__ import annotations
import argparse, asyncio, concurrent.futures, hashlib, json, math, os, random, shutil, subprocess, sys, time, wave
from pathlib import Path
from typing import Any
import requests
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output'
DATA = ROOT / 'data'
STORY_DIR = ROOT / 'korku_motoru' / 'stories'
W, H, FPS = 1080, 1920, 24


def log(msg: str): print(f'[KORKU MOTORU] {msg}', flush=True)

def run(cmd: list[str], **kwargs):
    subprocess.run(cmd, check=True, **kwargs)

def load_story(path: Path) -> dict[str, Any]:
    data=json.loads(path.read_text(encoding='utf-8'))
    if data.get('duration_seconds') != 180: raise ValueError('Hikâye süresi 180 saniye olmalı.')
    # New episodes use 15 narrative beats × 3 shots = 45 scenes.
    if 'beats' in data:
        if len(data['beats']) != 15: raise ValueError('Yeni hikâye tam olarak 15 anlatı bölümü içermeli.')
        scenes=[]
        for beat_no,beat in enumerate(data['beats'],1):
            narration=beat.get('narration',[])
            if len(narration)!=3: raise ValueError(f'{beat_no}. anlatı bölümü üç seslendirme satırı içermeli.')
            for shot in range(3):
                shot_desc=['wide establishing shot','medium action shot','close-up reaction or evidence shot'][shot]
                scenes.append({'n':len(scenes)+1,'narration':narration[shot],
                  'prompt':beat['visual']+(' Show exactly one smartphone with a clean screen facing camera for a readable Turkish message overlay.' if shot==1 and beat.get('phone_text') else '')+' Camera framing: '+shot_desc+'.',
                  'phone_text':beat.get('phone_text','') if shot==1 else '',
                  'dialogue':beat.get('dialogue','') if shot==2 else '',
                  'environment':data.get('environment','')})
        data['scenes']=scenes
    if len(data.get('scenes', [])) != 45: raise ValueError('Hikâye tam olarak 45 sahne içermeli.')
    for i,scene in enumerate(data['scenes'],1):
        if scene.get('n') != i or not scene.get('prompt') or not scene.get('narration'):
            raise ValueError(f'Sahne {i} eksik veya sıra numarası hatalı.')
    return data

def _image_prompt(prompt: str, variant: int = 0, story: dict | None = None) -> str:
    """Keep Batu's face/design stable while allowing every episode its own world."""
    character=(story or {}).get('character_design',
      'Batu, 24-year-old illustrated young man, short messy dark brown hair, warm hazel-brown eyes, light-medium skin, charcoal gray crewneck sweatshirt and navy sweatpants.')
    environment=(story or {}).get('environment','')
    style=(
      'High-quality hand-drawn 2D cinematic animated film frame, vertical 9:16 composition, '
      'refined ink contours, detailed painted background, expressive natural acting, layered atmospheric lighting, '
      'professional illustrated feature-film quality, consistent facial proportions, no photorealism, no 3D. '
    )
    if variant==1:
      style='Polished 2D illustrated mystery film still, vertical portrait, cinematic composition, detailed painted environment, natural character acting, no photorealism, no 3D. '
    elif variant==2:
      style='Premium hand-drawn 2D animated movie frame, vertical portrait, painterly cinematic lighting, clean linework, rich environmental detail, no photorealism, no 3D. '
    # Strict object/text control: avoid duplicate phones and malformed AI lettering.
    controls=('Character identity lock: same Batu face, same eye shape and color, same nose, same hairstyle, same age and same clothing. '
      'Only include objects explicitly required by the scene. Do not duplicate phones, hands, fingers, screens or props. '
      'If the scene calls for one phone, show exactly one phone. If it explicitly calls for two phones, show exactly two. '
      'No random writing, no pseudo-letters, no logos, no watermarks, no subtitles or speech bubbles baked into the artwork. '
      'Keep device screens clean and unobstructed for exact Turkish text to be added in post-production. ')
    scene=prompt
    if variant==1:
      for old,new in [('horror','mystery'),('terrified','startled'),('blood','dark stain'),('attack','sudden movement')]: scene=scene.replace(old,new)
    elif variant==2:
      for old,new in [('horror','suspense'),('terrified','shocked'),('blood','dark mark')]: scene=scene.replace(old,new)
    return style+character+' Episode environment: '+environment+'. '+controls+'Scene: '+scene

def cloudflare_image(prompt: str, dest: Path, scene_no: int, story: dict):
    account=os.getenv('CLOUDFLARE_ACCOUNT_ID','').strip(); token=os.getenv('CLOUDFLARE_API_TOKEN','').strip()
    if not account or not token: raise RuntimeError('CLOUDFLARE_ACCOUNT_ID ve CLOUDFLARE_API_TOKEN GitHub Secrets olarak gerekli.')
    model=os.getenv('CF_IMAGE_MODEL','@cf/black-forest-labs/flux-2-klein-4b')
    url=f'https://api.cloudflare.com/client/v4/accounts/{account}/ai/run/{model}'
    headers={'Authorization': f'Bearer {token}', 'Accept': 'image/png'}
    last_error='Bilinmeyen görsel üretim hatası'
    # A 3030 safety flag is not a transient network error. Retry with progressively
    # more neutral wording while preserving the scene's story beat and composition.
    for attempt in range(3):
        multipart_fields={
            'prompt': (None, _image_prompt(prompt, attempt, story)),
            'width': (None, '768'),
            'height': (None, '1365'),
        }
        try:
            r=requests.post(url,headers=headers,files=multipart_fields,timeout=(20,180))
        except requests.RequestException as e:
            last_error=f'Bağlantı hatası: {e}'
            if attempt < 2:
                time.sleep(3 * (attempt + 1))
                continue
            raise RuntimeError(f'Cloudflare image API sahne {scene_no}: {last_error}') from e
        if r.ok:
            ctype=r.headers.get('content-type','')
            if 'application/json' in ctype:
                payload=r.json()
                if not payload.get('success'):
                    last_error=f'Cloudflare yanıtı: {str(payload)[:300]}'
                else:
                    import base64
                    raw=payload.get('result',{}).get('image')
                    if raw:
                        dest.write_bytes(base64.b64decode(raw))
                    else:
                        last_error='Cloudflare yanıtında görsel bulunamadı.'
            else:
                dest.write_bytes(r.content)
            if dest.exists() and dest.stat().st_size > 1000:
                try:
                    with Image.open(dest) as im:
                        im.verify()
                    return dest
                except Exception as e:
                    dest.unlink(missing_ok=True)
                    last_error=f'Üretilen dosya geçerli bir görsel değil: {e}'
        else:
            body=r.text[:500]
            last_error=f'HTTP {r.status_code} {body}'
            is_flagged=('3030' in body or 'Your output has been flagged' in body)
            retryable=(r.status_code == 429 or r.status_code >= 500)
            if not is_flagged and not retryable:
                raise RuntimeError(f'Cloudflare image API sahne {scene_no}: {last_error}')
        if attempt < 2:
            log(f'Sahne {scene_no}: görsel yeniden deneniyor ({attempt + 2}/3).')
            time.sleep(4 * (attempt + 1))
    raise RuntimeError(f'Cloudflare image API sahne {scene_no}: 3 deneme başarısız. Son hata: {last_error}')

def placeholder_image(scene: dict, dest: Path):
    # Local smoke-test fallback only; never used in a production run.
    im=Image.new('RGB',(768,1365),(12,18,32)); d=ImageDraw.Draw(im)
    d.ellipse((240,260,530,550),fill=(90,86,105),outline=(190,180,190),width=5)
    d.rectangle((180,520,590,1120),fill=(62,65,78),outline=(180,180,190),width=5)
    d.rectangle((500,80,700,220),fill=(20,30,45),outline=(120,150,180),width=3)
    d.text((35,30),f"SCENE {scene['n']:02d}",(230,230,240))
    d.text((35,1180),scene.get('screen','')[:40],fill=(235,235,245))
    im.save(dest)

def generate_images(story: dict, test_mode=False):
    folder=OUT/'episodes'/story['id']/'images'; folder.mkdir(parents=True,exist_ok=True)
    todo=[]
    for s in story['scenes']:
        p=folder/f"scene_{s['n']:02d}.png"
        if p.exists() and p.stat().st_size>1000:
            try:
                with Image.open(p) as im: im.verify()
                continue
            except Exception:
                p.unlink(missing_ok=True)
        todo.append((s,p))
    if test_mode:
        for s,p in todo: placeholder_image(s,p)
        return
    workers=max(1,min(int(os.getenv('IMAGE_WORKERS','4')),8))
    log(f'{len(todo)} sahne görseli üretilecek; eşzamanlı istek: {workers}')
    errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(cloudflare_image,s['prompt'],p,s['n'],story):(s,p) for s,p in todo}
        for f in concurrent.futures.as_completed(futures):
            s,p=futures[f]
            try: f.result(); log(f"Görsel hazır: {s['n']}/45")
            except Exception as e: errors.append((s['n'],str(e)))
    if errors: raise RuntimeError('Görsel üretimi tamamlanamadı: '+'; '.join(f'{n}: {e}' for n,e in errors[:8]))

def add_screen_text(image_path: Path, text: str, kind: str='dialogue'):
    """Render exact Turkish text after image generation, never trust AI-generated lettering."""
    if not text: return
    im=Image.open(image_path).convert('RGB'); d=ImageDraw.Draw(im)
    font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    bold_path='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
    try:
      font=ImageFont.truetype(bold_path if kind=='phone' else font_path,30 if kind=='phone' else 32)
      small=ImageFont.truetype(font_path,19)
    except Exception:
      font=ImageFont.load_default(); small=font
    margin=58; max_width=im.width-2*margin
    words=text.split(); lines=[]; line=''
    for word in words:
      candidate=(line+' '+word).strip()
      if d.textbbox((0,0),candidate,font=font)[2] <= max_width-44: line=candidate
      else:
        if line: lines.append(line)
        line=word
    if line: lines.append(line)
    line_h=font.size+12 if hasattr(font,'size') else 42
    box_h=max(112, 48+len(lines)*line_h)
    y=im.height-72-box_h
    if kind=='phone':
      d.rounded_rectangle((margin,y,im.width-margin,y+box_h),radius=26,fill=(18,25,38),outline=(120,160,190),width=3)
      d.text((margin+24,y+13),'MESAJ',font=small,fill=(145,190,220))
      ty=y+42
    else:
      d.rounded_rectangle((margin,y,im.width-margin,y+box_h),radius=28,fill=(22,25,34),outline=(155,165,185),width=3)
      ty=y+22
    for ln in lines:
      d.text((margin+24,ty),ln,font=font,fill=(245,246,250),stroke_width=0)
      ty+=line_h
    im.save(image_path)

def make_clip(image_path: Path, dest: Path, idx: int):
    # Free-mode animation: cinematic 2D camera motion over AI-generated scene art.
    direction='in' if idx%2==0 else 'out'
    if direction=='in': z="min(zoom+0.00055,1.052)"
    else: z="if(eq(on,1),1.052,max(zoom-0.00055,1.0))"
    vf=f"scale=1200:2134:force_original_aspect_ratio=increase,crop=1200:2134,zoompan=z='{z}':d={FPS*4}:s={W}x{H}:fps={FPS},setsar=1,format=yuv420p"
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-i',str(image_path),'-vf',vf,'-t','4','-r',str(FPS),'-an','-c:v','libx264','-preset','ultrafast','-crf','24',str(dest)])

def make_music(path: Path, duration=180, seed='video_001'):
    import numpy as np
    sr=22050; n=sr*duration; t=np.arange(n,dtype=np.float32)/sr
    seedv=int(hashlib.sha256(seed.encode()).hexdigest()[:8],16); rng=np.random.default_rng(seedv)
    freqs=rng.choice([43.65,55.0,65.41,73.42,82.41],size=4,replace=False)
    music=np.zeros(n,dtype=np.float32)
    for i,f in enumerate(freqs):
        phase=float(rng.random()*6.28); rate=float(rng.uniform(0.015,0.04))
        music += (0.10/(i+1))*np.sin(2*np.pi*f*t + phase + np.sin(2*np.pi*rate*t)*0.6)
    # Slow pulsing tension, generated uniquely from the episode ID.
    pulse=(0.55+0.45*np.sin(2*np.pi*0.11*t))
    noise=rng.normal(0,1,n).astype(np.float32)
    # Smooth noise into a very soft atmospheric layer.
    kernel=np.ones(700,dtype=np.float32)/700
    ambience=np.convolve(noise,kernel,mode='same')
    music=(music*pulse + ambience*0.035).astype(np.float32)
    fade=int(sr*3); music[:fade]*=np.linspace(0,1,fade); music[-fade:]*=np.linspace(1,0,fade)
    music=np.clip(music,-0.45,0.45)
    stereo=np.stack([music,music],axis=1)
    with wave.open(str(path),'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((stereo*32767).astype('<i2').tobytes())

def make_sfx(path: Path, duration=180):
    sr=22050; n=sr*duration; t=[i/sr for i in range(n)]; samples=[0.0]*n
    # Restrained, synthetic phone notification/vibration cues.
    for sec,freq in [(4.2,740),(16.1,660),(48.2,740),(52.1,520),(84.2,740),(96.2,520),(140.1,740),(164.2,660),(176.1,740)]:
        start=int(sec*sr); length=int(.16*sr)
        for j in range(length):
            if start+j<n: samples[start+j]+=0.12*math.sin(2*math.pi*freq*j/sr)*math.exp(-j/(sr*.05))
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(b''.join(int(max(-1,min(1,x))*32767).to_bytes(2,'little',signed=True) for x in samples))

async def make_voice(text: str, path: Path):
    import edge_tts
    voice=os.getenv('TTS_VOICE','tr-TR-AhmetNeural')
    communicate=edge_tts.Communicate(text,voice,rate=os.getenv('TTS_RATE','-7%'),pitch=os.getenv('TTS_PITCH','-3Hz'))
    await communicate.save(str(path))

def make_srt(story, path: Path):
    # Narration text captions are timed evenly by word count across the film.
    words=[]
    for s in story['scenes']: words.extend(s['narration'].split())
    chunks=[' '.join(words[i:i+7]) for i in range(0,len(words),7)]
    total=max(1,len(chunks));
    def ts(sec):
        ms=int(sec*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
        return f'{h:02}:{m:02}:{s:02},{ms:03}'
    lines=[]
    for i,c in enumerate(chunks):
        a=180*i/total; b=180*(i+1)/total
        lines += [str(i+1),f'{ts(a)} --> {ts(b)}',c,'']
    path.write_text('\n'.join(lines),encoding='utf-8')

def assemble(story, test_mode=False):
    episode_out=OUT/'episodes'/story['id']; clips=episode_out/'clips'; clips.mkdir(parents=True,exist_ok=True)
    for s in story['scenes']:
        img=OUT/'episodes'/story['id']/'images'/f"scene_{s['n']:02d}.png"
        overlay_text=s.get('phone_text') or s.get('screen') or s.get('dialogue','')
        overlay_kind='phone' if s.get('phone_text') else 'dialogue'
        if overlay_text and not test_mode:
            display_img=OUT/'episodes'/story['id']/'images'/f"scene_{s['n']:02d}_display.png"
            shutil.copy2(img,display_img); add_screen_text(display_img,overlay_text,overlay_kind)
            img_for_clip=display_img
        else: img_for_clip=img
        dest=clips/f"clip_{s['n']:02d}.mp4"
        if not dest.exists() or dest.stat().st_size<1000:
            make_clip(img_for_clip,dest,s['n'])
        log(f"Klip hazır: {s['n']}/45")
    concat=episode_out/'concat.txt'
    concat_lines = []
    for scene in story['scenes']:
        clip_path = clips / ('clip_{:02d}.mp4'.format(scene['n']))
        concat_lines.append("file '{}'".format(clip_path.as_posix()))
    concat.write_text('\n'.join(concat_lines), encoding='utf-8')
    silent=episode_out/'silent.mp4'
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy',str(silent)])
    music=episode_out/'music_unique.wav'; sfx=episode_out/'sfx.wav'; voice=episode_out/'narration.mp3'
    make_music(music,180,story['id']); make_sfx(sfx,180)
    narration=' '.join(s['narration'] for s in story['scenes'])
    asyncio.run(make_voice(narration,voice))
    make_srt(story,episode_out/'captions.srt')
    final=OUT/f"KORKU_MOTORU_BATU_{story['id'].upper()}.mp4"
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(silent),'-i',str(voice),'-i',str(music),'-i',str(sfx),'-filter_complex','[1:a]apad=whole_dur=180,atrim=0:180,volume=1.0[n];[2:a]volume=0.18[m];[3:a]volume=0.35[s];[m][s]amix=inputs=2:duration=longest[bg];[n][bg]amix=inputs=2:duration=longest:dropout_transition=2[a]','-map','0:v:0','-map','[a]','-t','180','-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart',str(final)])
    probe=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=width,height','-of','json',str(final)],text=True)
    meta=json.loads(probe); duration=float(meta['format']['duration']); video=next(x for x in meta['streams'] if x.get('codec_type')=='video') if any(x.get('codec_type')=='video' for x in meta['streams']) else meta['streams'][0]
    if abs(duration-180)>1.0: raise RuntimeError(f'Son video süresi 180 saniye değil: {duration}')
    if video.get('width')!=W or video.get('height')!=H: raise RuntimeError('Son video çözünürlük kontrolünden geçemedi.')
    log(f'Video kalite kontrolü başarılı: {duration:.2f}s, {W}x{H}')
    return final

def upload_youtube(video: Path, story: dict):
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    cid=os.getenv('YOUTUBE_CLIENT_ID',''); secret=os.getenv('YOUTUBE_CLIENT_SECRET',''); refresh=os.getenv('YOUTUBE_REFRESH_TOKEN','')
    if not all([cid,secret,refresh]): raise RuntimeError('YouTube OAuth secrets eksik.')
    creds=Credentials(None,refresh_token=refresh,token_uri='https://oauth2.googleapis.com/token',client_id=cid,client_secret=secret,scopes=['https://www.googleapis.com/auth/youtube.upload'])
    creds.refresh(Request())
    yt=build('youtube','v3',credentials=creds)
    body={'snippet':{'title':story['title']+' | Korku Hikâyesi','description':story['description']+'\n\n#Korku #Gizem #Shorts','tags':['Korku','Gizem','Korku Hikayesi','Animasyon','Shorts'],'categoryId':'24'},'status':{'privacyStatus':os.getenv('YOUTUBE_PRIVACY','public'),'selfDeclaredMadeForKids':False}}
    req=yt.videos().insert(part='snippet,status',body=body,media_body=MediaFileUpload(str(video),mimetype='video/mp4',resumable=True,chunksize=8*1024*1024))
    response=None
    while response is None:
        _,response=req.next_chunk()
    log('YouTube yükleme tamamlandı: '+response.get('id','id yok'))
    return response.get('id')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--self-test',action='store_true'); ap.add_argument('--no-upload',action='store_true'); ap.add_argument('--story',default=''); ap.add_argument('--next',action='store_true'); args=ap.parse_args()
    OUT.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    history_path=DATA/'history.json'; history=json.loads(history_path.read_text(encoding='utf-8')) if history_path.exists() else {'published':[]}
    published={x.get('id') for x in history.get('published',[])}
    queue=json.loads((STORY_DIR/'QUEUE.json').read_text(encoding='utf-8'))
    # Pilot video_001 is the already completed successful episode; do not accidentally re-upload it.
    if not history_path.exists():
      published.add('video_001')
      history={'published':[{'id':'video_001','status':'existing_successful_pilot','title':'Neden Hâlâ Uyanıksın?'}]}
    if args.story:
      story_file=STORY_DIR/args.story
    else:
      next_item=next((x for x in queue if x['id'] not in published and x.get('status')!='existing_pilot'),None)
      if not next_item:
        log('20 bölümlük yayın kuyruğu tamamlandı; yeni hikâye bulunmuyor.'); return
      story_file=STORY_DIR/(next_item['id']+'.json')
    story=load_story(story_file)
    if not args.self_test and story['id'] in published:
      log('Bu bölüm daha önce yayınlanmış; çift yükleme engellendi.'); return
    generate_images(story,args.self_test)
    final=assemble(story,args.self_test)
    if not args.self_test and not args.no_upload:
      video_id=upload_youtube(final,story)
      history.setdefault('published',[]).append({'id':story['id'],'video_id':video_id,'title':story['title'],'uploaded_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
      history_path.write_text(json.dumps(history,ensure_ascii=False,indent=2),encoding='utf-8')
    log('İşlem başarıyla tamamlandı: '+str(final))

if __name__ == '__main__':
    try: main()
    except Exception as e:
        log('HATA: '+str(e)); sys.exit(1)
