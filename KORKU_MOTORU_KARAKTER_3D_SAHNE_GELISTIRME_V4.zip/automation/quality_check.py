#!/usr/bin/env python3
"""MP4 visual smoke test: stream metadata, darkness, frozen/duplicate frames, and sample frames."""
import json, subprocess, sys, tempfile, pathlib, statistics
from PIL import Image, ImageStat, ImageChops

video = pathlib.Path(sys.argv[1])
report = pathlib.Path(sys.argv[2])
samples_dir = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else report.parent / 'sample-frames'
samples_dir.mkdir(parents=True, exist_ok=True)

def run(cmd):
    return subprocess.run(cmd, check=True, capture_output=True, text=True).stdout

meta = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(video)]))
streams = meta.get('streams', [])
v = next((s for s in streams if s.get('codec_type') == 'video'), None)
a = next((s for s in streams if s.get('codec_type') == 'audio'), None)
if not v:
    raise SystemExit('FAIL: video stream missing')
width, height = int(v.get('width', 0)), int(v.get('height', 0))
duration = float(meta['format'].get('duration', 0))
if width != 1080 or height != 1920:
    raise SystemExit(f'FAIL: expected 1080x1920, got {width}x{height}')
if duration < 8:
    raise SystemExit(f'FAIL: suspicious video duration {duration:.2f}s')
if not a:
    raise SystemExit('FAIL: final MP4 has no audio stream')

# 16 evenly spaced samples. Check average brightness and near-black pixel share per sample.
count = 16
times = [max(.2, min(duration - .2, duration * i / (count + 1))) for i in range(1, count + 1)]
means, dark_shares, frames = [], [], []
for old in samples_dir.glob('sample-*.jpg'):
    old.unlink()
with tempfile.TemporaryDirectory() as td:
    for i, t in enumerate(times):
        tmp = pathlib.Path(td) / f'{i:02}.jpg'
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', str(t), '-i', str(video), '-frames:v', '1', '-vf', 'scale=180:320', str(tmp)], check=True)
        im = Image.open(tmp).convert('RGB')
        luma = im.convert('L')
        mean = ImageStat.Stat(luma).mean[0]
        dark = sum(1 for px in luma.get_flattened_data() if px < 12) / (luma.width * luma.height)
        means.append(mean); dark_shares.append(dark); frames.append(im)
        im.save(samples_dir / f'sample-{i+1:02d}-at-{t:.1f}s.jpg', quality=90)
# Fail when the entire sampled clip is dark, or when most samples are dark and the clip is globally dim.
if max(means) < 14:
    raise SystemExit('FAIL: all sampled frames are extremely dark (mean luma < 14)')
if statistics.mean(means) < 22 and statistics.mean(dark_shares) > .72:
    raise SystemExit(f'FAIL: overall video too dark (mean luma {statistics.mean(means):.1f}; dark pixels {statistics.mean(dark_shares):.0%})')
diffs = [ImageStat.Stat(ImageChops.difference(x, y)).mean[0] for x, y in zip(frames, frames[1:])]
if max(diffs, default=0) < .15:
    raise SystemExit('FAIL: sampled frames show virtually no visual change')
result = {
    'status': 'PASS', 'file': str(video), 'duration_seconds': round(duration, 2),
    'resolution': f'{width}x{height}', 'fps': v.get('r_frame_rate'),
    'audio_codec': a.get('codec_name'), 'sample_count': count,
    'sample_mean_luma': round(statistics.mean(means), 2),
    'sample_dark_pixel_share_mean': round(statistics.mean(dark_shares), 3),
    'sample_frame_difference_mean': round(statistics.mean(diffs), 3),
    'sample_frames_dir': str(samples_dir),
    'note': 'Automated visual smoke check; not a substitute for manual review.'
}
report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
