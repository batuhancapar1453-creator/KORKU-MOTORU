# KORKU MOTORU — Otomatik Shorts paketi

Bu paket, çalışan Yumurta-Stili `engine/` klasörünü değiştirmez. Yeni `son-gorulme` hikâyesi ve otomasyon dosyaları eklenmiştir.

## Kurulum
1. `KORKU_MOTORU_OTOMATIK_PAKET.zip` dosyasını GitHub deposunun kök dizinine yükleyin. ZIP adı aynı kalmalı. Workflow ZIP içeriğini otomatik açar. Mevcut çalışan YAML dosyanızı silmeyin; yeni workflow ayrı dosya olarak eklenir.
2. `KORKU_MOTORU_OTOMATIK.yml` dosyasını `.github/workflows/` içine `korku-motoru-otomatik.yml` adıyla koyun.
3. GitHub → Settings → Secrets and variables → Actions bölümünde şu üç secret oluşturun: `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, `YOUTUBE_REFRESH_TOKEN`.
4. Workflow'u önce `workflow_dispatch` ile bir kez elle çalıştırın. İlk çalıştırmada GitHub deposunda `automation/queue.json` kalıcı kuyruk dosyasını oluşturur.

## Yayın kuyruğu
Sezon 1 toplam 10 bağlantılı bölümdür. Her başarılı YouTube yüklemesinden sonra `automation/queue.json` bir sonraki bölüme ilerler. 10. bölümden sonra kuyruk durur; tekrar veya alakasız içerik yüklemez.

## Zamanlama
Cron render başlangıçlarını Türkiye saati 07:30 ve 10:30 olarak ayarlar; hedef yayın 09:00 ve 12:00'dir. Render süresi değiştiği için YouTube'a yükleme tam dakikada garanti edilemez; render bitince yayınlanır.

## Önemli
- YouTube OAuth secrets olmadan yayın yapılamaz.
- GitHub Actions dakika kotası depo görünürlüğüne ve hesaba bağlıdır. Bu pakette kota sınırsızmış gibi varsayılmaz.
- Edge TTS çevrimiçi ücretsiz erişilebilirlik koşullarına bağlıdır.
- Kelime zamanları Edge TTS SRT segmentlerinden yaklaşık dağıtılır; tam fonetik hizalama değildir.
- Orijinal çalışan workflow ayrı dosya olarak korunmalıdır.

## V4 karakter modeli güncellemesi ve kapsam notu

V4'te ana karakter Canvas billboard çizimi yerine Three.js 3D geometriyle oluşturulur: sabit yuvarlak beyaz kafa, ayrı gözler/pupiller, kaşlar, burun, ağız, ince gövde, eklemli kollar-bacaklar, parmaklar ve beyaz spor ayakkabılar. Animasyon aynı model üzerinde uygulanır; sahne değişimi karakter geometrisini değiştirmez.


**Hikâye kapsamı:** `automation/episodes.json` şu anda 10 ayrı hikâyeyi değil, `Son Görülme` adlı tek hikâyenin 10 ardışık bölümünü içerir. Workflow mevcut bölüm kuyruğunu kullanır; kaynak veride 10 ayrı hikâyenin ilk bölümü bulunmadığı için bu ZIP onları uydurarak üretmez.

**Doğrulama:** JavaScript/Python statik kontrolleri yapılır. Gerçek Chrome/Three.js render testi bu çalışma ortamında npm bağımlılıkları kurulmadığından tamamlanmadı. İlk GitHub Actions çalıştırmasında `publish=false` bırakıp render artefaktlarını inceleyin.
