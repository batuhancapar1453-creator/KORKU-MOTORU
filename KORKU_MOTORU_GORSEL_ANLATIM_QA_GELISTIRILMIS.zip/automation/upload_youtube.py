import os,json,sys,pathlib
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
root=pathlib.Path(__file__).resolve().parents[1]; idx=int(sys.argv[1]); eps=json.load(open(root/'automation/episodes.json',encoding='utf-8')); ep=eps[idx-1]
need=['YOUTUBE_CLIENT_ID','YOUTUBE_CLIENT_SECRET','YOUTUBE_REFRESH_TOKEN']
missing=[x for x in need if not os.getenv(x)]
if missing: raise SystemExit('Eksik GitHub Secrets: '+', '.join(missing))
creds=Credentials(None,refresh_token=os.environ['YOUTUBE_REFRESH_TOKEN'],token_uri='https://oauth2.googleapis.com/token',client_id=os.environ['YOUTUBE_CLIENT_ID'],client_secret=os.environ['YOUTUBE_CLIENT_SECRET'],scopes=['https://www.googleapis.com/auth/youtube.upload'])
youtube=build('youtube','v3',credentials=creds,cache_discovery=False)
files=list((root/'stories'/'son-gorulme'/'out').glob('*.mp4'))
if not files: raise SystemExit('Render MP4 bulunamadı')
video=max(files,key=lambda p:p.stat().st_mtime)
body={'snippet':{'title':f"SON GÖRÜLME | Bölüm {idx}/10: {ep['title']}",'description':f"SON GÖRÜLME: 03.17\n10 bölümlük paranormal gerilim serisi.\nBölüm {idx}/10 — {ep['title']}\n\n#Shorts #Korku #Gizem #Paranormal",'tags':['Shorts','korku','paranormal','gizem','gerilim'],'categoryId':'24'},'status':{'privacyStatus':'public','selfDeclaredMadeForKids':False}}
req=youtube.videos().insert(part='snippet,status',body=body,media_body=MediaFileUpload(str(video),chunksize=8*1024*1024,resumable=True))
res=None
while res is None:
 status,res=req.next_chunk()
 if status: print('Upload %d%%'%int(status.progress()*100))
print('YOUTUBE_VIDEO_ID='+res['id'])
