#!/usr/bin/env python3
"""Post-render MP4 sanity checks: stream metadata, sampled darkness, and frame variation."""
import json, subprocess, sys, tempfile, pathlib, statistics
from PIL import Image, ImageStat, ImageChops

video=pathlib.Path(sys.argv[1])
report=pathlib.Path(sys.argv[2])
def run(cmd): return subprocess.run(cmd,check=True,capture_output=True,text=True).stdout
meta=json.loads(run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]))
streams=meta.get('streams',[]); v=next((s for s in streams if s.get('codec_type')=='video'),None); a=next((s for s in streams if s.get('codec_type')=='audio'),None)
if not v: raise SystemExit('FAIL: video stream missing')
width,height=int(v.get('width',0)),int(v.get('height',0)); duration=float(meta['format'].get('duration',0))
if width!=1080 or height!=1920: raise SystemExit(f'FAIL: expected 1080x1920, got {width}x{height}')
if duration<8: raise SystemExit(f'FAIL: suspicious video duration {duration:.2f}s')
if not a: raise SystemExit('FAIL: final MP4 has no audio stream')
# Extract 12 evenly distributed frame samples for visual smoke tests.
times=[max(.2,min(duration-.2,duration*i/13)) for i in range(1,13)]
means=[]; frames=[]
with tempfile.TemporaryDirectory() as td:
 for i,t in enumerate(times):
  out=pathlib.Path(td)/f'{i:02}.jpg'
  subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(video),'-frames:v','1','-vf','scale=180:320',str(out)],check=True)
  im=Image.open(out).convert('RGB'); means.append(sum(ImageStat.Stat(im).mean)/3); frames.append(im)
if max(means)<8: raise SystemExit('FAIL: all sampled frames are nearly black')
# Very conservative duplicate test: only fail when every sample is essentially identical.
diffs=[]
for x,y in zip(frames,frames[1:]): diffs.append(ImageStat.Stat(ImageChops.difference(x,y)).mean[0])
if max(diffs,default=0)<0.15: raise SystemExit('FAIL: sampled frames show virtually no visual change')
result={'status':'PASS','file':str(video),'duration_seconds':round(duration,2),'resolution':f'{width}x{height}','fps':v.get('r_frame_rate'),'audio_codec':a.get('codec_name'),'sampled_frame_mean_luma_rgb':round(statistics.mean(means),2),'sampled_adjacent_frame_diff':round(statistics.mean(diffs),3),'note':'Automated smoke test only; not a human visual review.'}
report.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(result,ensure_ascii=False,indent=2))
