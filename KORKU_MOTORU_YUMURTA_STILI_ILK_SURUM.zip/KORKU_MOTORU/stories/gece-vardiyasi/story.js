// 03:17 — Gece Vardiyası. Original horror story built on the Yumurta-Stili engine.
import * as THREE from 'three';
import { Toon, flap, blinkAt } from '/engine/src/toon.js';
import { CamPath, smoother } from '/engine/src/camera.js';
import { stoneTex, woodTex, painted, flat } from '/engine/src/paint.js';

export const NAME = '03-17-gece-vardiyasi';
export const FPS = 30;
export let DUR = 41.5;
export const CUES = [];
export const LOOK = {
  cem: { body: 'coat', cloth: '#263b58', clothDark: '#17243a', trim: '#71849a', hair: '#25202a', height: 1.72, headW: 276, headH: 258 },
  kopya: { body: 'coat', cloth: '#1b263c', clothDark: '#101827', trim: '#46536b', hair: '#25202a', height: 1.72, headW: 276, headH: 258 },
  oturan: { body: 'sit', cloth: '#263b58', clothDark: '#17243a', trim: '#71849a', hair: '#25202a', height: 1.28, headW: 276, headH: 258 }
};

const smooth = smoother;
const clamp = (x, a=0, b=1) => Math.max(a, Math.min(b, x));
const V = (x,y,z) => new THREE.Vector3(x,y,z);
let W, cast = {}, camPath, lights = {}, props = {}, ctx0;

function wordTimes(words) {
  const norm = s => s.toLocaleLowerCase('tr-TR').replace(/[^\p{L}\p{N}]/gu, '');
  return (word, nth=1) => { let n=0; for (const x of words) if (norm(x.word) === norm(word) && ++n === nth) return x.start; throw new Error('word not found: '+word); };
}
function box(scene, size, pos, material, opts={}) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  m.position.set(...pos); m.castShadow = opts.cast ?? true; m.receiveShadow = opts.receive ?? true;
  scene.add(m); return m;
}
function addPoint(scene, color, intensity, pos, distance=0, decay=1) {
  const l = new THREE.PointLight(color, intensity, distance, decay); l.position.set(...pos); l.castShadow = true;
  l.shadow.mapSize.set(1024,1024); l.shadow.bias = -.001; l.shadow.normalBias = .025; scene.add(l); return l;
}
function bulb(scene, pos, color='#ffcf87', scale=.11) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(scale, 20, 14), new THREE.MeshBasicMaterial({color: new THREE.Color(color).multiplyScalar(2.2)}));
  m.position.set(...pos); scene.add(m); return m;
}
function wallPanel(scene, x, y, z, w, h, color) {
  const m = box(scene,[w,h,.09],[x,y,z],flat(color),{cast:false});
  return m;
}
function buildSecurity(scene) {
  const x=0;
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(14,14), painted(woodTex({base:'#39445b',rep:[3,3],seed:9}))); floor.rotation.x=-Math.PI/2; floor.position.set(x,0,0); scene.add(floor);
  const wallMat=painted(stoneTex({base:'#34435d',rep:[3,2],seed:14}));
  box(scene,[14,6,.35],[x,3,-5],wallMat); box(scene,[.35,6,12],[-7,3,0],wallMat); box(scene,[.35,6,12],[7,3,0],wallMat);
  // painted acoustic panels and a heavy door behind the guard
  for(let i=0;i<5;i++) wallPanel(scene,-5.3+i*2.65,3,-4.79,2.1,2.8,['#42516b','#34435d','#3b4b66'][i%3]);
  box(scene,[1.4,3,.22],[5.5,1.5,-4.72],painted(woodTex({base:'#493b45',rep:[1,2],vertical:true})));
  props.doorHandle = new THREE.Group(); props.doorHandle.position.set(4.98,1.45,-4.57); scene.add(props.doorHandle);
  const dh = new THREE.Mesh(new THREE.SphereGeometry(.075,16,12),flat('#c69b63')); props.doorHandle.add(dh);
  const dl = new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.22,10),flat('#c69b63')); dl.rotation.z=Math.PI/2; dl.position.x=-.12; props.doorHandle.add(dl);
  // desk, monitor bank, telephone and wall clock
  box(scene,[5.2,.22,2.0],[-.2,1.15,-.1],painted(woodTex({base:'#674a3c',rep:[2,1]})));
  box(scene,[.18,1.1,1.65],[-2.5,.55,-.1],flat('#283246')); box(scene,[.18,1.1,1.65],[2.1,.55,-.1],flat('#283246'));
  for(let i=0;i<3;i++){
    const xx=-1.7+i*1.45;
    box(scene,[1.25,.82,.12],[xx,2.12,-1.12],flat('#101a2b'));
    box(scene,[1.12,.68,.025],[xx,2.12,-1.04],flat(i===1?'#234c63':'#172f49'),{cast:false});
    // faint CCTV scan lines
    for(let k=0;k<5;k++) box(scene,[1.02,.012,.012],[xx,1.86+k*.13,-1.015],flat('#4e8090'),{cast:false});
  }
  box(scene,[.42,.1,.72],[-2.05,1.32,-.45],flat('#1b1b29'));
  box(scene,[.23,.08,.38],[-2.05,1.42,-.45],flat('#d6a45d'));
  // 03:17 digital clock, seven-segment-like glowing bars
  box(scene,[1.15,.55,.12],[0,4.55,-4.7],flat('#121b2b'));
  for(let i=0;i<4;i++) box(scene,[.16,.055,.035],[-.34+i*.23,4.55,-4.61],flat('#f2a45e'),{cast:false});
  lights.security = addPoint(scene,'#f3bd79',5,[0,4.8,-.5],14,1.4); bulb(scene,[0,5.25,-.5]);
  lights.screen = addPoint(scene,'#5b9acb',1.8,[-1.4,2.3,-1.1],6,1.8);
  const fill = new THREE.HemisphereLight('#526b9a','#171b2b',1.05); scene.add(fill);
  props.phone = new THREE.Group(); scene.add(props.phone); props.phone.position.set(-2.05,1.43,-.45);
  const base= new THREE.Mesh(new THREE.BoxGeometry(.34,.12,.52),flat('#252632')); props.phone.add(base);
  const handset=new THREE.Mesh(new THREE.CapsuleGeometry(.045,.32,4,8),flat('#161923')); handset.rotation.z=Math.PI/2; handset.position.y=.11; props.phone.add(handset); props.phone.userData.handset=handset;
}
function buildCorridor(scene) {
  const x=100;
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(8,28),painted(stoneTex({base:'#46536c',rep:[2,7],seed:31}))); floor.rotation.x=-Math.PI/2; floor.position.set(x,0,-5); scene.add(floor);
  const wm=painted(stoneTex({base:'#39465f',rep:[2,3],seed:22}));
  box(scene,[8,4,.28],[x,2,-19],wm); box(scene,[.28,4,28],[x-4,2,-5],wm); box(scene,[.28,4,28],[x+4,2,-5],wm);
  // apartment doors and frames on both sides
  for(let i=0;i<5;i++){
    const z=-17+i*5.4;
    box(scene,[.12,2.65,1.55],[x-3.78,1.32,z],painted(woodTex({base:'#59444b',rep:[1,2],vertical:true,seed:i+1})));
    box(scene,[.12,2.65,1.55],[x+3.78,1.32,z-1.5],painted(woodTex({base:'#51414d',rep:[1,2],vertical:true,seed:i+8})));
    box(scene,[.16,.08,.08],[x-3.68,1.15,z+.5],flat('#c69b63'));
  }
  // ceiling lights in cold pools, one flickering amber exit sign
  for(let i=0;i<4;i++){
    const z=-17+i*7;
    box(scene,[1.1,.08,.42],[x,3.82,z],flat('#b8d9ef'),{cast:false});
    addPoint(scene,'#9bc9ed',2.8,[x,3.65,z],8,1.5);
  }
  box(scene,[.8,.35,.08],[x+3.72,3.1,-17],flat('#a94c49'),{cast:false});
  addPoint(scene,'#d16b55',1.3,[x+3.3,3.1,-17],4,1.8);
  lights.corridor = new THREE.HemisphereLight('#7184ad','#191c32',.7); lights.corridor.position.set(x,5,0); scene.add(lights.corridor);
}
function buildStairs(scene) {
  const x=200;
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(10,16),painted(stoneTex({base:'#38445e',rep:[3,4],seed:41}))); floor.rotation.x=-Math.PI/2; floor.position.set(x,0,-2); scene.add(floor);
  const wm=painted(stoneTex({base:'#35415b',rep:[2,3],seed:42}));
  box(scene,[10,5,.3],[x,2.5,-10],wm); box(scene,[.3,5,16],[x-5,2.5,-2],wm); box(scene,[.3,5,16],[x+5,2.5,-2],wm);
  // rising concrete steps and metal rail
  for(let i=0;i<10;i++) box(scene,[3.7,.22,.78],[x-1.2, .12+i*.24, -6+i*.78],painted(stoneTex({base:'#68718a',seed:i+50,rep:[1,1]})));
  for(let i=0;i<9;i++){
    const z=-5.7+i*.78, y=.55+i*.24;
    box(scene,[.075,.95,.075],[x+1.1,y,z],flat('#8b9bad'));
  }
  box(scene,[.1,.1,8],[x+1.1,1.55,-2.2],flat('#a7b1c2'));
  box(scene,[1.0,3,.16],[x-3.8,1.5,-9.75],painted(woodTex({base:'#58454e',rep:[1,2],vertical:true})));
  box(scene,[.85,.08,.04],[x-3.3,2.35,-9.64],flat('#d2a76c'));
  lights.stairs=addPoint(scene,'#e4a76c',3,[x-3.1,3.9,-7.4],10,1.4); bulb(scene,[x-3.1,4.1,-7.4]);
  const cool=new THREE.HemisphereLight('#596e9d','#161a2b',.9); scene.add(cool);
}
function camera() {
  const t=W;
  return new CamPath([
    {t:0,pos:[-1.2,2.1,6.4],look:[-.7,1.8,-.7],fov:49,creep:.28},
    {t:t('Bakın')-.18,dur:.7,move:'whip',pos:[99.2,1.9,5.8],look:[100,1.55,-5],fov:52,creep:.25},
    {t:t('Koridorda')-.2,dur:1.1,pos:[98.7,1.8,2.4],look:[100,1.55,-11],fov:46,creep:.25},
    {t:t('kaldırıp')-.15,dur:.9,pos:[100,1.6,-1.8],look:[100,1.55,-17],fov:43,creep:.28},
    {t:t('merdivene')-.2,dur:.7,move:'whip',pos:[198.8,2.2,4.2],look:[199.8,1.7,-3.5],fov:48,creep:.22},
    {t:t('monitördeki')-.1,dur:.9,move:'whip',pos:[-.5,2.0,5.8],look:[0,1.9,-.8],fov:50,creep:.25},
    {t:t('arkasında,')-.15,dur:.8,pos:[-.4,2.0,3.4],look:[0,1.8,-1.5],fov:42,creep:.3}
  ],{fps:FPS,creep:.25,drift:.08});
}

export async function setup(ctx) {
  ctx0=ctx; W=wordTimes(ctx.words); const {scene}=ctx;
  scene.background=new THREE.Color('#171d35');
  buildSecurity(scene); buildCorridor(scene); buildStairs(scene);
  cast.cem=new Toon(LOOK.cem,scene); cast.copy=new Toon(LOOK.kopya,scene); cast.seated=new Toon(LOOK.oturan,scene);
  camPath=camera();
  const cue=(word,type,extra={})=>CUES.push({t:+W(word).toFixed(3),type,...extra});
  cue('Bakın','whoosh'); cue('merdivene','whoosh'); cue('monitördeki','whoosh'); cue('kaldırıp','rise',{dur:.7});
  cue('açtı.','boom'); cue('lense','wind',{dur:2.2}); cue('indiğini','lock'); cue('arkasında,','boom');
  CUES.push({t:0,type:'lamps',dur:W('Bakın')});
  DUR=Math.ceil((ctx.words[ctx.words.length-1].end+.55)*FPS)/FPS;
}

export function frame(t,ctx) {
  const {cam,env}=ctx;
  const cp=camPath.apply(cam,t), x=cam.position.x;
  const set=x<50?'security':x<150?'corridor':'stairs';
  // keep only the lights belonging to the current set enabled
  for(const [k,l] of Object.entries(lights)) if(l.isLight) l.visible=(k===set || (k==='screen'&&set==='security'));
  const tint=[1,1,1], night='#c7c9ed', warm='#ffc17d';
  cast.cem.hide(); cast.copy.hide(); cast.seated.hide();
  const talking=flap(env,t);
  if(set==='security'){
    const ending=t>W('arkasında,')-.35;
    if(ending){
      cast.seated.show(); cast.seated.place(-.65,0,1.0,cam,tint,1,0);
      cast.seated.draw({expr:'worried',look:0,lookY:0,blink:blinkAt(t,12,[W('arkasında,')],FPS),lit:1,shade:night,rim:{color:warm,a:.3}});
      cast.seated.castFrom(lights.security.position);
      cast.copy.show(); cast.copy.place(1.25,0,-2.15,cam,[.82,.86,1],1,0);
      cast.copy.draw({expr:'grin',look:0,lookY:-.2,blink:blinkAt(t,13,[W('arkasında,')],FPS),lit:-1,shade:night,rim:{color:'#8fa9d8',a:.3}});
      cast.copy.castFrom(lights.security.position);
    } else {
      cast.cem.show(); cast.cem.place(-.65,0,1.0,cam,tint,1,0);
    const phoneRing=.5+.5*Math.sin(t*18);
    props.phone.userData.handset.rotation.z=Math.PI/2+Math.sin(t*18)*.12*(t< W('açtı.')?1:0);
    cast.cem.draw({expr:t<W('numara')?'worried':t<W('düşündü.')?'surprised':'focused',look:t<W('açtı.')?-.5:.3,lookY:.2,brow:t<W('düşündü.')?.6:.2,blink:blinkAt(t,4,[W('numara'),W('düşündü.')],FPS),mouth:t<W('açtı.')?talking:0,armR:[t<W('açtı.')?95:35,t<W('açtı.')?10:45],armL:[25,20],lit:1,shade:night,rim:{color:warm,a:.38}});
    cast.cem.castFrom(lights.security.position);
    }
  } else if(set==='corridor') {
    cast.cem.show(); cast.copy.show();
    cast.cem.place(98.8,0,1.0,cam,tint,1,0);
    cast.copy.place(100,0,-16.7,cam,[.78,.82,1],1,0);
    cast.cem.draw({expr:'worried',look:.5,lookY:-.2,brow:.7,blink:blinkAt(t,7,[W('biri'),W('kaldırıp')],FPS),mouth:talking,armR:[35,50],armL:[-25,25],lit:-1,shade:night,rim:{color:'#7ca5dc',a:.3}});
    cast.copy.draw({expr:t>W('lense')?'grin':'neutral',look:0,lookY:-.1,brow:t>W('lense')?.5:0,blink:blinkAt(t,9,[W('lense')],FPS),mouth:0,armR:[8,5],armL:[-8,5],lit:1,shade:'#b8c4e8',rim:{color:'#8fa9d8',a:.22}});
    cast.cem.castFrom(V(100,3,-14)); cast.copy.castFrom(V(100,3,-14));
  } else {
    cast.cem.show(); cast.cem.place(198.7,0,1.0,cam,tint,1,0);
    cast.cem.draw({expr:'surprised',look:-.8,lookY:.5,brow:1,blink:blinkAt(t,4,[W('merdivene')],FPS),mouth:talking,armR:[-65,70],armL:[25,20],lean:-4,lit:1,shade:night,rim:{color:warm,a:.4}});
    cast.cem.castFrom(lights.stairs.position);
  }
  // door handle slowly turns during the final warning
  const doorTurn=clamp((t-W('kolunun'))/1.2);
  if(props.doorHandle) props.doorHandle.rotation.z=-doorTurn*.72;
  if(props.phone.userData.handset) props.phone.userData.handset.rotation.z=Math.PI/2+Math.sin(t*18)*.08*(t<W('açtı.')?1:0);
  const look={focus:cam.position.distanceTo(V(set==='security'?-.6:set==='corridor'?100:199,1.7,set==='security'?-.7:-7)),coc:7,range:3,sat:1.18,lift:[.09,.085,.16],bloom:.85,vignette:.23};
  look.blur=cp.moving>.15?16:0;
  look.tint=set==='security'?[1,.98,1.04]:set==='corridor'?[.92,.98,1.08]:[1,.95,.88];
  look.flash=t>W('değişti.')&&t<W('değişti.')+.06?.3:0;
  return look;
}
