# 03:17 — Gece Vardiyası

## Tür
Kurgu / paranormal gizem / psikolojik korku.

## Anlatım metni

Gece bekçisi Cem, saat üçü on yedi geçe boş binanın yedinci katından gelen telefonu açtı. Ama o katta yıllardır kimse yaşamıyordu. Bakın, ekranda arayan numara kendi dairesiydi. Cem bunun bir arıza olduğunu düşündü. Sonra güvenlik kameralarına baktı. Koridorda biri duruyordu. Aynı mont, aynı yüz... kendisiydi. Kameradaki adam başını kaldırıp doğrudan lense baktı. Telefon yeniden çaldı. Bu kez ahizeden Cem'in kendi sesi geldi: “Sakın merdivene çıkma.” Cem arkasındaki kapının kolunun yavaşça indiğini gördü. O sırada monitördeki görüntü değişti. Kamerada artık güvenlik odası vardı. Cem sandalyesinde oturuyordu. Ama arkasında, ona benzeyen biri ayakta duruyordu.

## Görsel plan

1. Güvenlik odasında Cem, 03:17'yi gösteren dijital saate ve çalan telefona uzanır.
2. Telefon ekranında kendi dairesinin numarasını görür.
3. Monitörde uzun, soğuk ışıklı apartman koridoru belirir.
4. Koridorun sonunda Cem'e tıpatıp benzeyen ikinci bir figür görünür.
5. Figür başını kaldırıp güvenlik kamerasına bakar.
6. Cem'in arkasındaki kapı kolu kendi kendine aşağı iner.
7. Son monitör görüntüsünde Cem sandalyede, kopyası ise arkasında durmaktadır.

## Prodüksiyon notu

Bu ilk uyarlama, Yumurta-Stili motorunun orijinal 2D yumurta-kafa karakterlerini, 3D setlerini, kamera, ışık, hareket ve kare yakalama sistemini kullanır. Hikâye ve sahne tasarımı özgündür. Süre, kaynak motorun 30–65 saniyelik Shorts yaklaşımına göre yaklaşık 40 saniyedir.

Ses dosyası kullanıcı tarafından sağlandığında `voice/words.json` ve `voice/env.json` dosyaları gerçek kayda göre `tools/kelime_saat.py` ve `tools/zarf.py` ile yeniden üretilmelidir. Bu paketteki kelime zamanları ilk görsel taslak içindir.
