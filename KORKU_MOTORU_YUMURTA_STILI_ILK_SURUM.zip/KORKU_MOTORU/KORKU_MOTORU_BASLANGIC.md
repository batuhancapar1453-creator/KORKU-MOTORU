# KORKU MOTORU — Yumurta-Stili tabanlı korku hikâyeleri

Bu proje, gönderdiğiniz `yumurta-stili` deposunun motorunu temel alır. Three.js 3D dünya, Canvas 2D yumurta-kafa karakterler, kamera, ışık, post-process, Puppeteer kare yakalama, FFmpeg ve ses miks altyapısı korunmuştur. Yeni içerik örneği `stories/gece-vardiyasi/` altındadır. Orijinal `stories/is-odasi/` örneği de kaynak projeyi karşılaştırabilmeniz için korunmuştur.

## İlk hikâye

**03:17 — Gece Vardiyası**: Boş bir binada çalışan güvenlik görevlisi Cem, kendi dairesinden gelen telefonu açar. Güvenlik kamerasında kendisinin bir kopyasını görür. Hikâye kurgu paranormal gizem/korku türündedir.

## Kurulum

Gerekenler: Node.js 18+, Python 3.10+, FFmpeg ve Google Chrome/Chromium.

```bash
cd engine
npm install
cd ..
pip install -r requirements.txt
```

## Ön izleme

```bash
cd engine
node serve.mjs
```

Tarayıcıda `http://127.0.0.1:8123/engine/index.html?story=gece-vardiyasi` adresini açın.

## Render

```bash
cd engine
node render.mjs gece-vardiyasi --stills=1,5,10,16,23,30,37 --scale=0.5
node render.mjs gece-vardiyasi
```

## Seslendirme

`stories/gece-vardiyasi/voice/script.txt` anlatım metnidir. Kaydedilmiş/TTS ses dosyanızı `voice/voice.wav` olarak ekleyin. Ardından proje araçlarıyla gerçek kelime zamanlarını ve dudak zarfını üretin:

```bash
python tools/kelime_saat.py stories/gece-vardiyasi/voice/voice.wav stories/gece-vardiyasi/voice/script.txt stories/gece-vardiyasi/voice/words.json
python tools/zarf.py stories/gece-vardiyasi/voice/voice.wav stories/gece-vardiyasi/voice/env.json
```

Paket içindeki `words.json` ilk görsel taslak için yaklaşık zamanlar içerir; gerçek ses eklendiğinde mutlaka yeniden üretilmelidir. Ses dosyası olmadan render sessiz video üretir. Ses miksini hazırlamak için önce `node render.mjs gece-vardiyasi --cues`, ardından `python audio/mix.py ../stories/gece-vardiyasi`, son olarak render komutunu çalıştırın.

## Önemli

Bu ilk teslim, orijinal motorun yapısını koruyan **tek bir korku hikâyesi prototipidir**. Henüz Android veya GitHub Actions üzerinde kurulum/otomatik yayınlama paketi değildir. İlk önce sahne kalitesini ve hareketleri kontrol edeceğiz; ardından aynı hikâye formatında yeni paranormal/gizem hikâyeleri ekleyeceğiz.
